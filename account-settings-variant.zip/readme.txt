Thanks for visiting MaterialDesignIcons.com
Check back often for new icons and follow @MaterialIcons for updates.

Icon: account-settings-variant
By: Cody @XT3000